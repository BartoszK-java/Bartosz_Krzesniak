const canvas = document.getElementById('wannabetetris');
const ctx = canvas.getContext('2d');

// Rozmiar klocka
const blockSize = 20;

// Pozycja początkowa klocka
let blockX = (canvas.width - blockSize) / 2; // Środek planszy w osi X
let blockY = 0; // Start u góry

// Prędkość spadania
const gravity = 2;

// Prędkość poruszania na boki
const moveSpeed = 20;

// Flaga zatrzymania klocka
let isFalling = true;

// Rysowanie klocka
function drawBlock() {
    ctx.fillStyle = 'blue';
    ctx.fillRect(blockX, blockY, blockSize, blockSize);
}

// Aktualizacja pozycji klocka
function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Czyszczenie planszy

    if (isFalling) {
        blockY += gravity; // Spadanie klocka

        // Sprawdzanie kolizji z dolną krawędzią planszy
        if (blockY + blockSize >= canvas.height) {
            blockY = canvas.height - blockSize; // Zatrzymaj na dole
            isFalling = false;
        }
    }

    drawBlock(); // Rysowanie klocka
    requestAnimationFrame(update); // Kontynuowanie animacji
}

// Obsługa klawiatury
document.addEventListener('keydown', (event) => {
    if (!isFalling) return; // Brak ruchu, jeśli klocek przestał spadać

    if (event.key === 'ArrowLeft') {
        blockX -= moveSpeed; // Przesunięcie w lewo
        if (blockX < 0) blockX = 0; // Ograniczenie ruchu do lewej krawędzi
    } else if (event.key === 'ArrowRight') {
        blockX += moveSpeed; // Przesunięcie w prawo
        if (blockX + blockSize > canvas.width) blockX = canvas.width - blockSize; // Ograniczenie ruchu do prawej krawędzi
    }
});

// Uruchomienie gry
update();
